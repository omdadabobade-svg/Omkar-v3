# Omkar Apps (Customer + Admin)

This repo contains two Flutter apps. GitHub Actions will scaffold Android projects automatically and build APKs.

## How to use (mobile-friendly)
1. Upload this repo to GitHub.
2. Ensure `.github/workflows/build.yml` exists.
3. Go to **Actions** → run **Build Omkar Apps**.
4. Download APKs from Artifacts.
